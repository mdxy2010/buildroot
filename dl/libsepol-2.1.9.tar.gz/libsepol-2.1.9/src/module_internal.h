#include <sepol/module.h>
#include "dso.h"

hidden_proto(sepol_module_package_create)
    hidden_proto(sepol_module_package_free)
